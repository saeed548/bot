<?php
flush();
ini_set("log_errors" , "off");
set_time_limit(0);

ob_start();

include("jdf.php");

$API_KEY = '[*[TOKEN]*]';
##------------------------------##
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown"
    ]);
}

function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function ForwardMessage($ChatId,$from_chat,$message_Id){
 bot('ForwardMessage',[
 'chat_id'=>$ChatId,
 'from_chat_id'=>$from_chat,
 'message_id'=>$message_Id
 ]);
 }

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

function objectToArrays($object)
{
    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map("objectToArrays", $object);
}


//====================ᵗᶦᵏᵃᵖᵖ======================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$channel_post = $update->message->channel_post;
$code = file_get_contents("data/code.txt");
$code2 = file_get_contents("data/code2.txt");
$chid = $update->channel_post->message->message_id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$c_id = $message->forward_from_chat->id;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
@$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
@$penlist = file_get_contents("data/pen.txt");
$text = $message->text;
@mkdir("data/$chat_id");
@$ali = file_get_contents("data/$chat_id/ali.txt");
@$list = file_get_contents("users.txt");
$ADMIN = [*[ADMIN]*];
$channel = file_get_contents("data/channel.txt");
$channel2 = file_get_contents("data/channel2.txt");
$starttx = file_get_contents("data/starttx.txt");
$setcoin2 = file_get_contents("data/setcoin2.txt");
$setcoinn = file_get_contents("data/setcoin.txt");
$setshop = file_get_contents("data/shops.txt");
$uzername = file_get_contents("data/uzernamo.txt");
$txtzirm = file_get_contents("data/txttzir.txt");
$txtvip = file_get_contents("data/txvvip.txt");
$setarezir = file_get_contents("data/coinruz.txt");
$type = file_get_contents("data/bottype.txt");
$ttttt = file_get_contents("data/tttt.txt");
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$fromm_id = $update->inline_query->from->id;
$fromm_user = $update->inline_query->from->username;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$fatime = jdate("h:i:s");
$fadate = jdate("Y F d");
//====================ᵗᶦᵏᵃᵖᵖ======================//
$ptn = json_encode([
    'inline_keyboard' => [
        [
            ['text' => "1⃣", 'callback_data' => "c1"], ['text' => "2⃣", 'callback_data' => "c2"], ['text' => "3⃣", 'callback_data' => "c3"]
        ],
        [
            ['text' => "4⃣", 'callback_data' => "c4"], ['text' => "5⃣", 'callback_data' => "c5"], ['text' => "6⃣", 'callback_data' => "c6"]
        ],
        [
            ['text' => "7⃣", 'callback_data' => "c7"], ['text' => "8⃣", 'callback_data' => "c8"], ['text' => "9⃣", 'callback_data' => "c9"]
        ],
        [
            ['text' => "چک کن😊", 'callback_data' => "chk"], ['text' => "0⃣", 'callback_data' => "c0"]
        ],
        [
            ['text' => "بازگشت به صفحه اصلی", 'callback_data' => "home"]
        ],
    ]
]);
////_________
if ($text == "/start" && $type == "o") {
        SendMessage($chat_id,"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @CandoCreateBot
✊️با سرور قوی و پرسرعت💪","html","true");
 }
if ($text == "/start") {

        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
            file_put_contents("data/$chat_id/membrs.txt", "0");
            file_put_contents("data/$chat_id/shoklat.txt", "10");
            file_put_contents('users.txt', $add_user);
        }
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
'text' => "$starttx",
            'parse_mode' => "MarkDown",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💰جمع آوری سکه💰", 'callback_data' => "a"]
                    ],
                    [
                        ['text' => "👤زیر مجموعه گیری👤", 'callback_data' => "b"], ['text' => "👤 حساب کاربری من", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "📡ثبت تبلیغ", 'callback_data' => "e"], ['text' => "🚀انتقال سکه💰", 'callback_data' => "d"]
                    ],
                    [
                        ['text' => "🏦مغازه", 'callback_data' => "f"], ['text' => "⁉️راهنما", 'callback_data' => "g"]
                    ],
                    [
                        ['text' => "📊پیگیری تبلیغات", 'callback_data' => "h"], ['text' => "🎁کد سکه ای", 'callback_data' => "k"]
                    ],
                    [
                        ['text' => "💰سکه روزانه", 'callback_data' => "j"],
                    ],
                    
                ]
            ])
        ]);
    } elseif (strpos($penlist, "$from_id")) {
        SendMessage($chat_id, "کاربر عزیز شما از سرور ما بلاک شدید.
دیگه پیام ندید با تشکر🙏");
    } elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "چجور خودت میخوای با لینک خودت عضو ربات بشی انوقت سکه هم میخوای؟",
            ]);
        } elseif (strpos($list, "$from_id") !== false) {
            SendMessage($chat_id, "شما قبلا در این ربات عضو شدی و نمیتونی با لینک عضویت دوستت عضو ربات بشی😑");
        } else {
            sendAction($chat_id, 'typing');
            @$sho = file_get_contents("data/$newid/shoklat.txt");
            $getsho = $sho + $setcoin2;
            file_put_contents("data/$newid/shoklat.txt", $getsho);
            @$sea = file_get_contents("data/$newid/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents("data/$newid/membrs.txt", $getsea);
            $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
                $add_user = file_get_contents('users.txt');
                $add_user .= $from_id . "\n";
                file_put_contents("data/$chat_id/membrs.txt", "0");
                file_put_contents("data/$chat_id/shoklat.txt", "10");
                file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$chat_id/ali.txt", "No");
            sendmessage($chat_id, "تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "$starttx",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                    [
                        ['text' => "💰جمع آوری سکه💰", 'callback_data' => "a"]
                    ],
                    [
                        ['text' => "👤زیر مجموعه گیری👤", 'callback_data' => "b"], ['text' => "👤 حساب کاربری من", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "📡ثبت تبلیغ", 'callback_data' => "e"], ['text' => "🚀انتقال سکه💰", 'callback_data' => "d"]
                    ],
                    [
                        ['text' => "🏦مغازه", 'callback_data' => "f"], ['text' => "⁉️راهنما", 'callback_data' => "g"]
                    ],
                    [
                        ['text' => "📊پیگیری تبلیغات", 'callback_data' => "h"], ['text' => "🎁کد سکه ای", 'callback_data' => "k"]
                    ],
                    [
                        ['text' => "💰سکه روزانه", 'callback_data' => "j"],
                    ],
                    
                ]
            ])
        ]);
            SendMessage($newid, "🌹تبریک
یک نفر با لینک زیر مجموعه گیری شما وارد ربات شد و شما $setcoin2 سکه گرفتید.");
        }
    }
    elseif ($data == "home") {
    unlink("cod/$chatid.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "no");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "$starttx",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💰جمع آوری سکه💰", 'callback_data' => "a"]
                    ],
                    [
                        ['text' => "👤زیر مجموعه گیری👤", 'callback_data' => "b"], ['text' => "👤 حساب کاربری من", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "📡ثبت تبلیغ", 'callback_data' => "e"], ['text' => "🚀انتقال سکه💰", 'callback_data' => "d"]
                    ],
                    [
                        ['text' => "🏦مغازه", 'callback_data' => "f"], ['text' => "⁉️راهنما", 'callback_data' => "g"]
                    ],
                    [
                        ['text' => "📊پیگیری تبلیغات", 'callback_data' => "h"], ['text' => "🎁کد سکه ای", 'callback_data' => "k"]
                    ],
                    [
                        ['text' => "💰سکه روزانه", 'callback_data' => "j"],
                    ],
                    
                ]
            ])
        ]);
    } elseif ($data == "a") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "یه لحظه صبر کن",
            'show_alert' => false
        ]);
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "🌹به بخش دریافت سکه رایگان خوش آمدید.
با کلیک بر روی دکمه (♻️ثبت بازدید)  در زیر هر پست در کانال زیر سکه جمع آوری کنید و پست های کانال خود را بازدید بزنید.
$channel",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت به صفحه اصلی", 'callback_data' => "home"]
                    ]
                ]
            ])
        ]);
        
    }
    elseif ($data == "k") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "🎁کد سکه ای مورد نظر را وارد کنید.
لطفا با صفحه کلیدی که توسط من نمایان شد این کد را وارد کنید😊",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c1") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "1");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c2") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "2");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c3") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "3");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c4") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "4");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c5") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "5");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c6") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "6");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c7") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "7");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c8") {
        $fromm_id = $update->inline_query->from->id;
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "8");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c9") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "9");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "c0") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "0");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد وارد شده شما :
$cod",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "chk") {
        $fromm_id = $update->inline_query->from->id;
        $cod = file_get_contents("cod/$chatid.txt");
        $code2 = file_get_contents("data/code2.txt");
        if ($cod == $code && $cod != null) {
            @$sho = file_get_contents("data/$chatid/shoklat.txt");
            $getsho = $sho + $code2;
            file_put_contents("data/$chatid/shoklat.txt", $getsho);
            unlink("cod/$chatid.txt");
            file_put_contents("data/code.txt", "");
            file_put_contents("data/code2.txt", "");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "🎁تبریک کد شما درست بود و شما برنده $code2 سکه رایگان شدید😱😍",
                'show_alert' => true
            ]);
            bot('sendMessage', [
                'chat_id' => $channel2,
                'text' => "🎁کد سکه ای $code استفاده شد.
 
 توسط 👇
🆔 آیدی فرد :
$chatid 
💰 تعداد سکه های اضافه شده :
$code2
⏰ ساعت :
$fatime
📅 تاریخ :
$fadate
➖➖➖➖➖➖➖➖
$channel2
@$uzername
➖➖➖➖➖➖➖➖",

            ]);
            file_put_contents("data/$chatid/ali.txt", "no");
            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "$starttx",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
[
                        ['text' => "💰جمع آوری سکه💰", 'callback_data' => "a"]
                    ],
                    [
                        ['text' => "👤زیر مجموعه گیری👤", 'callback_data' => "b"], ['text' => "👤 حساب کاربری من", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "📡ثبت تبلیغ", 'callback_data' => "e"], ['text' => "🚀انتقال سکه💰", 'callback_data' => "d"]
                    ],
                    [
                        ['text' => "🏦مغازه", 'callback_data' => "f"], ['text' => "⁉️راهنما", 'callback_data' => "g"]
                    ],
                    [
                        ['text' => "📊پیگیری تبلیغات", 'callback_data' => "h"], ['text' => "🎁کد سکه ای", 'callback_data' => "k"]
                    ],
                    [
                        ['text' => "💰سکه روزانه", 'callback_data' => "j"]
                    ],
                    
                ]
            ])
        ]);
        } else {
            unlink("cod/$chatid.txt");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کد سکه ای مورد نظر وجود نداره یا اینکه قبلا استفاده شده🚫",
                'show_alert' => true
            ]);
            file_put_contents("data/$chatid/ali.txt", "no");
            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "$starttx",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
[
                        ['text' => "💰جمع آوری سکه💰", 'callback_data' => "a"]
                    ],
                    [
                        ['text' => "👤زیر مجموعه گیری👤", 'callback_data' => "b"], ['text' => "👤 حساب کاربری من", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "📡ثبت تبلیغ", 'callback_data' => "e"], ['text' => "🚀انتقال سکه💰", 'callback_data' => "d"]
                    ],
                    [
                        ['text' => "🏦مغازه", 'callback_data' => "f"], ['text' => "⁉️راهنما", 'callback_data' => "g"]
                    ],
                    [
                        ['text' => "📊پیگیری تبلیغات", 'callback_data' => "h"], ['text' => "🎁کد سکه ای", 'callback_data' => "k"]
                    ],
                    [
                        ['text' => "💰سکه روزانه", 'callback_data' => "j"]
                    ],
                    
                ]
            ])
        ]);
        }
    } elseif ($data == "b") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        bot('sendmessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "$txtzirm
http://telegram.me/$uzername?start=$chatid",
        ]);
        bot('sendmessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "با انتشار پست بالا، به ازای هر فردی که با لینک شما به ربات دعوت شود، $setcoin2 سکه به حساب شما اضافه خواهد شد👆",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی❤️", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "j") {
        date_default_timezone_set('Asia/Tehran');
        $date = date('Ymd');
        @$gettime = file_get_contents("data/$chatid/dates.txt");
        if ($gettime == $date) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "عزیزم سکه روزانه امروزتو گرفتی.
صبر کن فردا بیاد تا دوباره بهت سکه بدم😏",
                'show_alert' => true
            ]);
        } else {
            file_put_contents("data/$chatid/dates.txt", $date);
            @$sho = file_get_contents("data/$chatid/shoklat.txt");
$ran = ($setarezir);
            $getsho = $sho + $ran;
            file_put_contents("data/$chatid/shoklat.txt", $getsho);
            $sho2 = file_get_contents("data/$chatid/shoklat.txt");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "😊آخجان سکه روزانه گرفتی😍
اونم $ran سکه❤️",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "f") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "💰مغازه سکه ای💳

⁉️شما میتوانید با زدن بر روی هرکدام از گزینه های زیر به پشتیبانی ما وصل شده و سکه خریداری کنید.
لطفا در توضیحات خود آیدی عددی خود را نیز برای ما ارسال نمایید.

⚪️ایدی عددی شما : $chatid",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "500 سکه | 2500 هزار تومان", 'url' => "https://t.me/$setshop"]
                    ],
                    [
                        ['text' => "2000 سکه | 10000 هزار تومان", 'url' => "https://t.me/$setshop"]
                    ],
                    [
                        ['text' => "5000 سکه | 25000 هزار تومان", 'url' => "https://t.me/$setshop"]
                    ],
                        [
                        ['text' => "10000 سکه | 50000 هزار تومان", 'url' => "https://t.me/$setshop"]
                    ],
                    [
                        ['text' => "برگشت به منوی اصلی ", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "c") {
        @$sho = file_get_contents("data/$chatid/shoklat.txt");
        @$sea = file_get_contents("data/$chatid/membrs.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "👤آیدی عددی شما : $chatid
💰سکه های شما : $sho
تعداد زیرمجموعه های شما : $sea",
            'show_alert' => true
        ]);
    } elseif ($data == "g") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "وقتتون بخیر 
ربات بازدیدگیر رباتی که شما با استفاده از اون میتونید برای پست ها و چالش ها کانال ها ویو یا همون سین جمع کنید😊
کار باهاش هم راحته سکه جمع میکنی و سکه هاتو به سین (ویو) تبدیل میکنید",
            'show_alert' => true
        ]);
    } elseif ($data == "d") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "for");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "🚀لطفا پیامی از کاربر مورد نظر فروارد کنید",
        ]);
    } elseif ($ali == "for") {
        if ($from_id == $forward_id) {
            SendMessage($chat_id, "شرمنده پیام خودتون را برام فروارد نکنید☹️️");
        } else {
            if (strpos($list, "$forward_id") !== false) {
                file_put_contents("data/$chat_id/ali.txt", "fore");
                file_put_contents("data/$chat_id/for.txt", $forward_id);
                bot('sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "خب چه مقدار سکه میخواهید برای کاربر $forward_id انتقال بدید😊",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => [
                            [
                                ['text' => "ولش بریم منوی اصلی🙃", 'callback_data' => "home"]
                            ],
                        ]
                    ])
                ]);
            } else {
                SendMessage($chat_id, "شرمنده این کاربر در ربات ما عضو نمیباشد☹️");
            }
        }
    } elseif ($ali == "fore") {
        if (preg_match('/^([0-9])/', $text)) {
            if ($shoklt > $text) {
                $fr = file_get_contents("data/$chat_id/for.txt");
                $fle = file_get_contents("data/$fr/shoklat.txt");
                $fl = file_get_contents("data/$chat_id/shoklat.txt");
                $s = $text;
                $getsh = $fl - $s;
                file_put_contents("data/$chat_id/shoklat.txt", $getsh);
                SendMessage($chat_id, "😏سکه های شما با موفقیت به کاربر مورد نظر شما انتقال داده شدند.");
                $getshe = $fle + $s;
                file_put_contents("data/$fr/shoklat.txt", $getshe);
                SendMessage($fr, "تبریک کاربر $chat_id برای شما $text سکه ارسال کرد");
            } else {
                SendMessage($chat_id, "شرمنده سکه های شما کافی نیست❌");
            }
        } else {
            SendMessage($chat_id, "خوب کاربر عزیز یه عدد فقط بصورت لاتین بفرستید 😶");
        }
    } elseif ($data == "e") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب کاربر گرامی پست شما چقدر ویو (سین) بخوره❓
هر ویو برابر یک سکه میباشد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "👁‍🗨20 ویو | 20 سکه💰", 'callback_data' => "seen20"]
                    ],
                    [
                        ['text' => "👁‍🗨45 ویو | 45 سکه💰", 'callback_data' => "seen45"]
                    ],
                    [
                        ['text' => "👁‍🗨80 ویو | 80 سکه💰", 'callback_data' => "seen80"]
                    ],
                    [
                        ['text' => "👁‍🗨130 ویو | 130 سکه💰", 'callback_data' => "seen130"]

                    ],
                    [
                        ['text' => "👁‍🗨240 ویو | 240 سکه💰", 'callback_data' => "seen240"]
                    ],
                    [
                        ['text' => "👁‍🗨300 ویو | 300 سکه💰", 'callback_data' => "seen300"]
                    ],
                    [
                        ['text' => "برگشت به منوی اصلی ", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
        elseif ($data == "seen20") {
        file_put_contents("data/$chatid/ted.txt", "20");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen45") {
        file_put_contents("data/$chatid/ted.txt", "45");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen80") {
        file_put_contents("data/$chatid/ted.txt", "80");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen130") {
        file_put_contents("data/$chatid/ted.txt", "130");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen240") {
        file_put_contents("data/$chatid/ted.txt", "240");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",

                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen300") {
        file_put_contents("data/$chatid/ted.txt", "300");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        file_put_contents("data/tttt.txt", "$aaa");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt < $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شرمنده سکه های شما کافی نیست❌",
                'show_alert' => true
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "خب کاربر گرامی لطفا تبلیغ خود را ارسال کنید♻️",
            ]);
        }
        } elseif ($ali == "seen2") {
        if ($forward_chat_username != null or $forward_chat_username == null ) {
            $msg_id = bot('ForwardMessage', [
                'chat_id' => $channel,
                'from_chat_id' => $chat_id,
                'message_id' => $message_id
            ])->result->message_id;
            bot('sendMessage', [
                'chat_id' => $channel,
                'text' => "👁‍🗨تعداد بازدید درخواستی👆 : $ttttt",
                'reply_to_message_id' => $msg_id,
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
                            ['text' => "♻️ثبت بازدید", 'callback_data' => "ok"], ['text' => "😎ورود به ربات", 'url' => "https://t.me/$uzername"]
                        ],
                    ]
                ])
            ]);

            @$al = file_get_contents("data/$chat_id/ted.txt");
            @$sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getsho = $sho - $al;
            file_put_contents("data/$chat_id/shoklat.txt", $getsho);
            @$don = file_get_contents("data/done.txt");
            $getdon = $don + 1;
            file_put_contents("data/done.txt", $getdon);
            file_put_contents("ads/cont/$msg_id.txt", $al);
            file_put_contents("ads/date/$msg_id.txt", $fadate);
            file_put_contents("ads/time/$msg_id.txt", $fatime);
            file_put_contents("ads/admin/$msg_id.txt", $chat_id);
            file_put_contents("ads/seen/$msg_id.txt", "0");
            file_put_contents("ads/user/$msg_id.txt", "");
            file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "خوب کاربر گرامی تبلیغ ‌شما با موفقیت در کانال ما ثبت شد😊

✔️مشخصات تبلیغ شما:
  🗓کد پیگیری : $msg_id
  👁‍🗨تعداد بازدید : $al
  ⏰ساعت درخواست بازدید :$fatime 
 📅تاریخ  : $fadate
 📎پست شما در کانال ما $channel قرار گرفت.
✂️تعداد سکه های کم شده : $al",
'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "برگشت به منوی اصلی ", 'callback_data' => "home"]
                    ],
                ]
            ])
            ]);
        } else {
            sendmessage($chat_id, "🙏لطفا از یه کانال عمومی پیام فراورد کن🙂");
        }
    }
    if ($data == "ok") {
        $message_id12 = $update->callback_query->message->reply_to_message->message_id;
        $fromm_id = $update->callback_query->from->id;
        @$ue = file_get_contents("ads/user/$message_id12.txt");
        @$se = file_get_contents("ads/seen/$message_id12.txt");
        if (strpos($ue, "$fromm_id") !== false) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "💰شما قبلا سکه این تبلیغ را گرفته اید❌",
                'show_alert' => false
            ]);
        } else {
            $user = file_get_contents("ads/user/$message_id12.txt");
            $members = explode("\n", $user);
            if (!in_array($fromm_id, $members)) {
                $add_user = file_get_contents("ads/user/$message_id12.txt");
                $add_user .= $fromm_id . "\n";
                file_put_contents("ads/user/$message_id12.txt", $add_user);
            }
            $getse = $se + 1;
            file_put_contents("ads/seen/$message_id12.txt", $getse);
            @$sho = file_get_contents("data/$fromm_id/shoklat.txt");
            $getsho = $sho + $setcoinn;
            file_put_contents("data/$fromm_id/shoklat.txt", $getsho);
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "✅$setcoinn سکه کسب کردید | موجودی شما : $sho",
                'show_alert' => false
            ]);
        }
        $end = file_get_contents("ads/seen/$message_id12.txt");
        $ad = file_get_contents("ads/admin/$message_id12.txt");
        $co = file_get_contents("ads/cont/$message_id12.txt");
        $te = file_get_contents("ads/time/$message_id12.txt");
        $de = file_get_contents("ads/date/$message_id12.txt");
        if ($end == $co) {
            file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $ad,
                'text' => "سفارش بازدید شما با کد پیگیری  **$message_id12**به پایان رسید😋

👁‍🗨تعداد بازدید درخواستی شما: $co
⏰ساعت درخواست بازدید: $te
📅تاریخ درخواست بازدید: $de
🕰ساعت اتمام درخواست بازدید: $fatime

موفق و سربلند باشید♥️",
                'parse_mode' => "MarkDown"
            ]);
            @$don = file_get_contents("data/done.txt");
            $getdon = $don - 1;
            file_put_contents("data/done.txt", $getdon);
            @$enn = file_get_contents("data/enf.txt");
            $getenf = $enn + 1;
            file_put_contents("data/enf.txt", $getenf);
            $de = $message_id12 + 1;
            deletemessage($channel, $message_id12);
            deletemessage($channel, $de);
            unlink("ads/seen/$message_id12.txt");
            unlink("ads/admin/$message_id12.txt");
            unlink("ads/cont/$message_id12.txt");
            unlink("ads/time/$message_id12.txt");
            unlink("ads/user/$message_id12.txt");
            unlink("ads/date/$message_id12.txt");
        }
    } elseif ($data == "h") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "mlm");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "کد پیگیری خودتون را برام بفرستید",
        ]);
    } elseif ($ali == "mlm") {
        file_put_contents("data/$chat_id/ali.txt", "");
        if (file_exists("ads/admin/$text.txt")) {
            $ge = file_get_contents("ads/seen/$text.txt");
            $ad = file_get_contents("ads/admin/$text.txt");
            $co = file_get_contents("ads/cont/$text.txt");
            $te = file_get_contents("ads/time/$text.txt");
            $de = file_get_contents("ads/date/$text.txt");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "مشخصات کد پیگیری  $text  بصورت زیر میباشد
👁‍🗨تعداد بازدید درخواستی شما: $co
⏰ساعت درخواست بازدید: $te
📅تاریخ درخواست بازدید: $de
👁تعداد بازدید در یافتی تا الان : $ge
🕰ساعت درخواست پیگیری: $fatime

موفق و سربلند باشید❤ ",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
                            ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                        ],
                    ]
                ])
            ]);
        } else {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "کد پیگیری شما اشتباه میباشد یا سفارش شما به پایان رسیده هست😬
موفق و سربلند باشید❤ ",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
                            ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                        ],
                    ]
                ])
            ]);
        }
    }

////----
if ($chatid == $ADMIN or $chat_id == $ADMIN) {
    if ($text == "/panel") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مدیر گرامی به پنل مدیریت ربات خود خوش آمدید.",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💰تنظیم سکه زیر مجموعه گیری", 'callback_data' => "setcoi"]
                    ],
                    [
                        ['text' => "👤آمار کلی ربات", 'callback_data' => "am"],['text' => "💢تنظیم متن استارت", 'callback_data' => "setstart"]
                    ],
                    [
                        ['text' => "📭پیام همگانی", 'callback_data' => "send"], ['text' => "✈️فروارد همگانی", 'callback_data' => "fwd"]
                    ],
                    [
                        ['text' => "❌بلاک کاربر", 'callback_data' => "pen"], ['text' => "⭕️آنبلاک کاربر️", 'callback_data' => "unpen"]
                    ],
                    [
                        ['text' => "🎁ساخت کد رایگان", 'callback_data' => "crl"], ['text' => "💸اهدای سکه", 'callback_data' => "buy"],
                    ],
                    [
                        ['text' => "🆔تنظیم کانال ارسال تبلیغات", 'callback_data' => "setc"]
                    ],
                    [
                        ['text' => "🆔تنظیم کانال ارسال کد سکه ای", 'callback_data' => "setc2"]
                    ],
                    [
                        ['text' => "☢تنظیم سکه دیدن تبلیغات", 'callback_data' => "setcoinn"]
                    ],
                    [
                        ['text' => "🛒تنظیم آیدی فروشگاه سکه", 'callback_data' => "setccaa"]
                    ],
                    [
                        ['text' => "👥تنظیم متن زیر مجموعه گیری", 'callback_data' => "settxtzirm"]
                    ],
                    [
                        ['text' => "🔅تنظیم سکه روزانه", 'callback_data' => "setcoinn3"]
                    ],
                    [
                        ['text' => "برگشت به منوی اصلی ", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    if ($text == "/start") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $ADMIN,
            'text' => "مدیر گرامی به ربات خود خوش آمدید برای رفتن به پنل مدیریت /panel را ارسال کنید.",
            ]);
    }
    elseif ($data == "am") {
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        @$don = file_get_contents("data/done.txt");
        @$enf = file_get_contents("data/enf.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "تعداد ممبر ها : $member_count
تعداد تبلیغات در حال انجام: $don
تعداد تبلیغات انجام شده: $enf",

            'show_alert' => true
        ]);
    } elseif ($data == "send") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "send");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا کاربرهای ربات",
        ]);
    } elseif ($ali == "send") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "fwd") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "fwd");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خودتون را فروارد کنید",
        ]);
    } elseif ($ali == 'fwd') {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "pen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "pen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات😡",
        ]);
    } elseif ($ali == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم😤
 ایدیش هم 
 $text ",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "unpen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "unpen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب شد بخشیدی ایدیشو بده از بلاکی درش بیارم",
        ]);
    } elseif ($ali == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setc") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب آدرس کانالتو همراه با @ برام بفرس",
        ]);
    }
    elseif ($ali == 'setc') {
        file_put_contents("data/channel.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله چنل تبلیغات این شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setccaa" && $type == "gold") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setcca");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب لطفا آیدی فروشگاه سکه رو بدون @ بفرس",
        ]);
    }
    elseif ($data == "setccaa" && $type == "o") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "aaaaaaa");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "❌متاسفانه ربات شما  ویژه نمیباشد
 برای خرید اشتراک ویژه:
 @BotFathers_Admin",
         'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($ali == 'setcca') {
        file_put_contents("data/shops.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله آیدی فروشگاه سکه این شد
 
 @$text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setstart") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setstart");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا متن استارت جدید رو بفرس",
        ]);
    } elseif ($ali == 'setstart') {
        file_put_contents("data/starttx.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "👇حله متن استارت  این شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($data == "settxtzirm") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "settxtzirm");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا متن زیر مجموعه گیری جدید رو بفرس
            توجه لینک اختصاصی عضویت به صورت خودکار زیر این متن قرار میگیرد.",
        ]);
    } elseif ($ali == 'settxtzirm') {
        file_put_contents("data/txttzir.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "👇حله متن زیر مجموعه گیری این شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($data == "setcoi" && $type == "gold") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setco");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا تعداد سکه های گرفتن زیر مجموعه رو به عدد لاتین یعنی انگلیسی بفرس.",
        ]);
    }
    elseif ($data == "setcoi" && $type == "o") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "aaaaaaa");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "❌متاسفانه ربات شما  ویژه نمیباشد
 برای خرید اشتراک ویژه:
 @BotFathers_Admin",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($ali == 'setco') {
        file_put_contents("data/setcoin2.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله تعداد سکه های زیر مجموعه گیری اینقدر شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($data == "setcoinn3" && $type == "gold") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setcoinn33");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا تعداد سکه های روزانه رو به عدد لاتین یعنی انگلیسی بفرس.",
        ]);
    }
    elseif ($data == "setcoinn3" && $type == "o") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "aaaaaaa");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "❌متاسفانه ربات شما  ویژه نمیباشد
 برای خرید اشتراک ویژه:
 @BotFathers_Admin",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($ali == 'setcoinn33') {
        file_put_contents("data/coinruz.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله تعداد سکه های روزانه اینقدر شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($data == "setcoinn") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setcoinn");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا تعداد سکه های دیدن تبلیغ رو به عدد لاتین یعنی انگلیسی بفرس.",
        ]);
    } elseif ($ali == 'setcoinn') {
        file_put_contents("data/setcoin.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله تعداد سکه های دیدن تبلیغ اینقدر شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
     elseif ($data == "setc2" && $type == "gold") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc22");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب یوزرنیم کانال ارسال کد سکه ای را بهمراه @ بفرس",
        ]);
    }
    elseif ($data == "setc2" && $type == "o") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "aaaaaaa");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "❌متاسفانه ربات شما  ویژه نمیباشد
 برای خرید اشتراک ویژه:
 @BotFathers_Admin",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($ali == 'setc22') {
        file_put_contents("data/channel2.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله چنل کد سکه ای این شد
 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "crl") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "crl");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب لطفا کد سکه ای را برای ساخت وارد کنید.❤️",
        ]);
    } elseif ($ali == 'crl') {
        file_put_contents("data/code.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "crl2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد سکه های این کد چقدر باشه",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($ali == 'crl2') {
        $code = file_get_contents("data/code.txt");
        $code2 = file_get_contents("data/code2.txt");
        file_put_contents("data/code2.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله کد شما ساخته شد و در کانال ارسال کد سکه ای ارسال شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
               $code = file_get_contents("data/code.txt");
        $code2 = file_get_contents("data/code2.txt");
        bot('sendMessage', [
            'chat_id' => $channel2,
            'text' => "یک کد سکه ای💰 ساخته شد.

🎁️کد سکه ای : $code 
🎁تعداد سکه ها : $code2
⚪️ساعت ساخت : $fatime

فقط یه نفر میتونه از این کد در ربات @$uzername استفاده کنه❤️
➖➖➖➖➖➖➖➖
$channel2
➖➖➖➖➖➖➖➖",
            ]);
        
        
        
        
        
    }
     elseif ($data == "buy") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "buy");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
        ]);
    } elseif ($ali == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد سکه ها چقدر باشه",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($ali == 'buy2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/shoklat.txt");
               $getshe = $fle + $text;
                file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر عزیز
از طرف مدیریت ربات  تعداد $text سکه به شما واریز شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }

}
elseif($text == '/creator'){
  SendMessage($chat_id,"این ربات توسط رباتساز پر قدرت و پرسرعت @CandoCreateBot ساخته شده است✅","html","true");
  }
?>
