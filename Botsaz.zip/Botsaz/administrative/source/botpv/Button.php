<?php
flush();
$button_manage = json_encode(['keyboard'=>[
// dokme bala	
[['text'=>'📬پروفایل']],// prt
// dokme paiin
[
['text'=>'✴️بخش مدیریت']]
],'resize_keyboard'=>true]);
$button_pasokh_sarih = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
// pasokh sarih
],'resize_keyboard'=>true]);
$button_dokme_remove = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
// dokme bala
// dokme paiin
],'resize_keyboard'=>true]);
$button_dokme_ha = json_encode(['keyboard'=>[
// dokme bala
[['text'=>'📬پروفایل']],// prt
// dokme paiin
],'resize_keyboard'=>true]);
?>