<?php
flush();
    // توجه سورس به دلیل جلو گیری از کلاه برداری برخی افراد اپن شده است باتشکر
//=============@CreateFastBot=============//
define('API_KEY','[*[TOKEN]*]');
$admin =  "[*[ADMIN]*]";
$TOKEN = API_KEY;
$adminid = file_get_contents('admin/username.txt');
$helptxt = file_get_contents('admin/help.txt');
$goldtxt = file_get_contents('admin/goldtxt.txt');
$starttxt = file_get_contents('starttxt.txt');
$vipbot = file_get_contents('vipbot.txt');
$GetINFObot = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getMe"));
$NameBot = $GetINFObot->result->first_name;
$UserNameBot = $GetINFObot->result->username;
$coinsend24 = file_get_contents('admin/coinsend.txt');

function save($filename,$TXTdata){
  $myfile = fopen($filename, "w") or die("Unable to open file!");
  fwrite($myfile, "$TXTdata");
  fclose($myfile);
  }
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendMessage($chatid,$text,$parsmde,$disable_web_page_preview,$keyboard){
  bot('sendMessage',[
  'chat_id'=>$chatid,
  'text'=>$text,
  'parse_mode'=>$parsmde,
  'disable_web_page_preview'=>$disable_web_page_preview,
  'reply_markup'=>$keyboard
  ]);
  }
function SendMessage2($chatid,$text,$message_id,$parsmde,$disable_web_page_preview,$keyboard){
  bot('sendMessage',[
  'chat_id'=>$chatid,
  'text'=>$text,
        'reply_to_message_id'=>$message_id,
  'parse_mode'=>$parsmde,
  'disable_web_page_preview'=>$disable_web_page_preview,
  'reply_markup'=>$keyboard
  ]);
  }
function ForwardMessage($chatid,$from_chat,$message_id){
  bot('ForwardMessage',[
  'chat_id'=>$chatid,
  'from_chat_id'=>$from_chat,
  'message_id'=>$message_id
  ]);
  }
function SendPhoto($chatid,$photo,$keyboard,$caption){
  bot('SendPhoto',[
  'chat_id'=>$chatid,
  'photo'=>$photo,
  'caption'=>$caption,
  'reply_markup'=>$keyboard
  ]);
  }
function SendAudio($chatid,$audio,$keyboard,$caption,$sazande,$title){
  bot('SendAudio',[
  'chat_id'=>$chatid,
  'audio'=>$audio,
  'caption'=>$caption,
  'performer'=>$sazande,
  'title'=>$title,
  'reply_markup'=>$keyboard
  ]);
  }
function SendDocument($chatid,$document,$keyboard,$caption){
  bot('SendDocument',[
  'chat_id'=>$chatid,
  'document'=>$document,
  'caption'=>$caption,
  'reply_markup'=>$keyboard
  ]);
  }
function SendSticker($chatid,$sticker,$keyboard){
  bot('SendSticker',[
  'chat_id'=>$chatid,
  'sticker'=>$sticker,
  'reply_markup'=>$keyboard
  ]);
  }
function SendVideo($chatid,$video,$keyboard,$duration){
  bot('SendVideo',[
  'chat_id'=>$chatid,
  'video'=>$video,
  'duration'=>$duration,
  'reply_markup'=>$keyboard
  ]);
  }
function SendVoice($chatid,$voice,$keyboard,$caption){
  bot('SendVoice',[
  'chat_id'=>$chatid,
  'voice'=>$voice,
  'caption'=>$caption,
  'reply_markup'=>$keyboard
  ]);
  }
function SendContact($chatid,$first_name,$phone_number,$keyboard){
  bot('SendContact',[
  'chat_id'=>$chatid,
  'first_name'=>$first_name,
  'phone_number'=>$phone_number,
  'reply_markup'=>$keyboard
  ]);
  }
function SendChatAction($chatid,$action){
  bot('sendChatAction',[
  'chat_id'=>$chatid,
  'action'=>$action
  ]);
  }
function KickChatMember($chatid,$user_id){
  bot('kickChatMember',[
  'chat_id'=>$chatid,
  'user_id'=>$user_id
  ]);
  }
function LeaveChat($chatid){
  bot('LeaveChat',[
  'chat_id'=>$chatid
  ]);
  }
function GetChat($chatid){
  bot('GetChat',[
  'chat_id'=>$chatid
  ]);
  }
function GetChatMembersCount($chatid){
  bot('getChatMembersCount',[
  'chat_id'=>$chatid
  ]);
  }
function GetChatMember($chatid,$userid){
  $truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=".$chatid."&user_id=".$userid));
  $tch = $truechannel->result->status;
  return $tch;
  }
function AnswerCallbackQuery($callback_query_id,$text,$show_alert){
  bot('answerCallbackQuery',[
        'callback_query_id'=>$callback_query_id,

'text'=>$text,
    'show_alert'=>$show_alert
    ]);
  }
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
   bot('editMessagetext',[
    'chat_id'=>$chat_id,
  'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
  'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
  ]);
  }
function EditMessageCaption($chat_id,$message_id,$caption,$keyboard,$inline_message_id){
   bot('editMessageCaption',[
    'chat_id'=>$chat_id,
  'message_id'=>$message_id,
    'caption'=>$caption,
    'reply_markup'=>$keyboard,
  'inline_message_id'=>$inline_message_id
  ]);
  }
  
$button_tiid = json_encode(['keyboard'=>[
[['text'=>'تایید شماره','request_contact'=>true]],
[['text'=>'چرا باید شمارمو تایید کنم']],
],'resize_keyboard'=>true]);
$button_manage = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
[['text'=>'پيام همگاني'],['text'=>'فوروارد همگانی']],
[['text'=>'آمار'],['text'=>'تنظیم متن استارت']],
[['text'=>'تنظیم متن بنر'],['text'=>'تنظیم پشتیبانی']],
[['text'=>'تنظیم ایدی کانال'],['text'=>'ویژه کردن ربات']],
],'resize_keyboard'=>true]);
$button_back = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
$button_nz = json_encode(['inline_keyboard'=>[
[['text'=>'نظر بعدی','callback_data'=>'nzr']],
],'resize_keyboard'=>true]);
$button_nza = json_encode(['inline_keyboard'=>[
[['text'=>'دریافت بنر','callback_data'=>'daryaft']],
[['text'=>'پشتیبانی تحویل بنر','callback_data'=>'poshtiban']],
],'resize_keyboard'=>true]);
$button_back1 = json_encode(['inline_keyboard'=>[
[['text'=>'برگشت','callback_data'=>'back menu']],
[['text'=>"ورود به پشتیبانی",'url'=>"https://telegram.me/$support"]],
],'resize_keyboard'=>true]);
$button_nsend_ads = json_encode(['inline_keyboard'=>[
[['text'=>'چرا تبلیغ ارسال نشد؟🤔','callback_data'=>'nsend ads']],
],'resize_keyboard'=>true]);
$button_t_ads = json_encode(['inline_keyboard'=>[
[['text'=>'تاييد تبليغ','callback_data'=>'taiid ads'],['text'=>'رد تبليغ','callback_data'=>'rad ads']],
],'resize_keyboard'=>true]);
$send_code_kibord = json_encode(['inline_keyboard'=>[[['text'=>"🔝ورود به ربات🔝 $NameBot",'url'=>"https://telegram.me/$UserNameBot"]],]]);

$update = json_decode(file_get_contents('php://input'));
$data = $update->callback_query->data;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->message->from->id;
$usrn = $update->callback_query->message->chat->username;
$usrn1 = $update->callback_query->message->from->username;
$messageid = $update->callback_query->message->message_id;
$data_id = $update->callback_query->id;
$txt = $update->callback_query->message->text;
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$from_username = $update->message->from->username;
$from_first = $update->message->from->first_name;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$text = $update->message->text;
$message_id = $update->message->message_id;
$stickerid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$voiceid = $update->message->voice->file_id;
$fileid = $update->message->document->file_id;
$photo = $update->message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$caption = $update->message->caption;
$cde = time();
$code = "$from_id$cde";
$datetime = json_decode(file_get_contents("https://api.feelthecode.xyz/date/?timezone=Asia/tehran"));
$time = file_get_contents("https://bot.elithost.ml/date/time/");
$date = file_get_contents("https://bot.elithost.ml/date/");
$spam1 = file_get_contents('user/'.$from_id."/spam1.txt");
$spam2 = file_get_contents('user/'.$from_id."/spam2.txt");
$antispam12 = $spam1 - $spam2;
$antispam121 = $antispam12;
$command = file_get_contents('command.txt');
$gold = file_get_contents('user/'.$from_id."/gold.txt");
$coin = file_get_contents('user/'.$from_id."/coin.txt");
$wait = file_get_contents('user/'.$from_id."/wait.txt");
$coin_wait = file_get_contents('user/'.$wait."/coin.txt");
$number = file_get_contents('user/'.$from_id."/number.txt");
$code_taiid = file_get_contents('user/'.$from_id."/code taiid.txt");
$Member = file_get_contents('admin/Member.txt');
$NZR = file_get_contents('admin/NZR.txt');
$bot_type_ads = file_get_contents('bot_type_ads.txt');
$Tedad_Nazar = file_get_contents('admin/Tedad Nazar.txt');
$ads = file_get_contents('ads/Ads.txt');
$cd = file_get_contents("user/$from_id/cd24.txt");
$coinsend = file_get_contents("admin/coinsend.txt");
$Tedad_Ads = file_get_contents('admin/Tedad Ads.txt');
$antispam = file_get_contents('user/'.$from_id."/antospam.txt");
$tch1 = file_get_contents('chanel.txt');
$allads = file_get_contents('ads/allads.txt');
$radads = file_get_contents("ads/radads.txt");
$shoptext = file_get_contents('admin/shoptext.txt');
$coinozv = file_get_contents('admin/coinozv.txt');
$fads = file_get_contents("ads/fads.txt");
$sdaycoin = file_get_contents('user/'.$from_id."/sdaycoin.txt");
$sdaycoin2 = $cde;
$sdaycoin1 = $sdaycoin2 - $sdaycoin;
$coinday = file_get_contents('user/'.$from_id."/coinday.txt");
$username = $update->message->from->username;
$banertxt = file_get_contents("banertxt.txt");
$support = file_get_contents("support.txt");
$bot_type_ads = file_get_contents("bot_type_ads.txt");

// start source
    if (strpos($block , "$from_id") !== false) {
  return false;
  }
  elseif ($from_id != $chat_id and $chat_id != $feed) {
  LeaveChat($chat_id);
  }
  //===============
  // start source
  elseif($data == 'poshtiban'){
    EditMessageText($chatid,$messageid,"بنر خود را پس از تکمیل کردن به ربات زیر بفرستید 
    @$support",'html','true',json_encode(['inline_keyboard'=>[
[['text'=>'برگشت','callback_data'=>'back menu']],
[['text'=>"ورود به پشتیبانی",'url'=>"https://telegram.me/$support"]],
],'resize_keyboard'=>true]));
  }
  //===============
  elseif($text == '/creator'){
  SendMessage($chat_id,"این ربات توسط رباتساز پر قدرت و پرسرعت @CandoCreateBot ساخته شده است✅","html","true");
  }
  //===============
  elseif($data == 'back menu'){
    EditMessageText($chatid,$messageid,"$starttxt","html","true",$button_nza);
  }
  //===============
  elseif($data == 'daryaft'){
    if($usrn == null){
   $pmtext = "$banertxt

@$usrn
تاریخ ثبت بنر :$date
ساعت ثبت بنر : $time
";
    }else{
         $pmtext = "$banertxt
@$usrn
تاریخ ثبت بنر :$date
ساعت ثبت بنر : $time
";
    }
  $msgid = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/sendMessage?parse_mode=HTML&chat_id=$tch1&text=".urlencode($pmtext)));
  $msg_id = $msgid->result->message_id;
   ForwardMessage($chatid,$tch1,$msg_id);
   AnswerCallbackQuery($data_id,"بنر برای شما با موفقیت ارسال شد");
  }
  //===============
  elseif(preg_match('/^\/([Ss]tart)(.*)/',$text)){
  preg_match('/^\/([Ss]tart)(.*)/',$text,$match);
  $match[2] = str_replace(" ","",$match[2]);
  $match[2] = str_replace("\n","",$match[2]);
  if($match[2] != null){
  if (strpos($Member , "$from_id") == false){
  if($match[2] != $from_id){
  if (strpos($gold , "$from_id") == false){
  $txxt = file_get_contents('user/'.$match[2]."/gold.txt");
    $pmembersid= explode("\n",$txxt);
    if (!in_array($from_id,$pmembersid)){
      $aaddd = file_get_contents('user/'.$match[2]."/gold.txt");
      $aaddd .= $from_id."\n";
    file_put_contents('user/'.$match[2]."/gold.txt",$aaddd);
    }
  $mtch = file_get_contents('user/'.$match[2]."/coin.txt");
  if($coinozv != null){
  file_put_contents("user/".$match[2]."/coin.txt",($mtch+10) );
  }else{
  file_put_contents("user/".$match[2]."/coin.txt",($mtch+$coinozv) );
  SendMessage($match[2],"🆕 یک نفر با لینک اختصاصی شما وارد ربات شد","html","true",$button_official);
  }
  }
  }
  } 
  } 
  if($bot_type_ads != 'gold'){
      SendMessage($chat_id,"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @CandoCreateBot
✊️با سرور قوی و پرسرعت💪","html","true");
  SendMessage($chat_id,"$starttxt","html","true",$button_nza);
  }else{
    SendMessage($chat_id,"$starttxt","html","true",$button_nza);
  }
  }
  //===============
  elseif($text == '/panel'){
    if($from_id == $admin){
    SendMessage($chat_id,"به مدیریت خوش آمدید.","html","true",$button_manage);
  }
  }
  //===============
  elseif($text == 'ویژه کردن ربات'){
      SendMessage($chat_id,"❌متاسفانه ربات شما  ویژه نمیباشد
 برای خرید اشتراک ویژه:
","html","true");
  }
  //===============
  elseif($text == '↩️منوی اصلی'){
    if($from_id == $admin){
  file_put_contents('command.txt',"none");
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید


⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_manage);
  }
  }
  //===============
  elseif($text == 'تنظیم متن بنر' and $from_id == $admin){
  file_put_contents('command.txt',"set baner");
  SendMessage($chat_id,"لطفا متن بنر را ارسال کنید","html","true",$button_back);
  }
  //===============
  elseif($command == 'set baner' and $from_id == $admin){
  file_put_contents('banertxt.txt',$text);
  file_put_contents('command.txt',"none");
  SendMessage($chat_id,"ثبت شد","html","true",$button_manage);
  }
  //===============
  elseif($text == 'تنظیم ایدی کانال' and $from_id == $admin){
  file_put_contents('command.txt',"set chanel");
  SendMessage($chat_id,"لطفا ایدی کانال برای ارسال بنر در آن را با @ وارد کنید","html","true",$button_back);
  }
  //===============
  elseif($command == 'set chanel' and $from_id == $admin){
$truechannel1 = json_decode(file_get_contents("https://api.telegram.org/bot[*[TOKEN]*]/getChat?chat_id=$text"));
$tch1 = $truechannel1->result->id;
  file_put_contents('chanel.txt',$tch1);
  file_put_contents('command.txt',"none");
  SendMessage($chat_id,"عالیه
  حالا کانال رو خصوصی کن تا ایدی نداشته باشه.","html","true",$button_manage);
  }
  //===============
  elseif($text == 'آمار' and $from_id == $admin){
  $txtt = file_get_contents('Member.txt');
    $member_id = explode("\n",$txtt);
    $mmemcount = count($member_id) -1;
  SendMessage($chat_id,"آمار شما تا ساعت $time و تاریخ $date به تعداد $mmemcount ممبر میباشد.","html","true",$button_manage);
  }
  //===============
  elseif($text == 'پيام همگاني' and $from_id == $admin){
  file_put_contents("command.txt","s2a");
  SendMessage($chat_id,"پيامتون رو وارد کنيد","html","true",$button_back);
  }
  //===============
  elseif($command == 's2a' and $from_id == $admin){
  file_put_contents("command.txt","none");
  SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
  $all_member = fopen( "Member.txt", 'r');
    while( !feof( $all_member)) {
       $user = fgets( $all_member);
      if($sticker_id != null){
      SendSticker($user,$stickerid);
      }
      elseif($videoid != null){
      SendVideo($user,$videoid,$caption);
      }
      elseif($voiceid != null){
      SendVoice($user,$voiceid,'',$caption);
      }
      elseif($fileid != null){
      SendDocument($user,$fileid,'',$caption);
      }
      elseif($musicid != null){
      SendAudio($user,$musicid,'',$caption);
      }
      elseif($photoid != null){
      SendPhoto($user,$photoid,'',$caption);
      }
      elseif($text != null){
      SendMessage($user,$text,"html","true");
      }
    }
  }
  //===============
  elseif($text == 'فوروارد همگانی'and $from_id == $admin){
  file_put_contents("command.txt","s2a fwd");
  SendMessage($chat_id,"پیام مورد نظر را فوروارد کنید","html","true",$button_back);
    }
    //===============
  elseif($command == 's2a fwd' and $from_id == $admin){
  file_put_contents("command.txt","none");
  SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
  $all_member = fopen( "Member.txt", 'r');
    while( !feof( $all_member)) {
       $user = fgets( $all_member);
      ForwardMessage($user,$admin,$message_id);
    }
  }
  //===============
  elseif($text == 'تنظیم متن استارت'and $from_id == $admin){
  file_put_contents("command.txt","set starttxt");
  SendMessage($chat_id,"پیامی که میخواهید به عنوان متن استارت باشد را ارسال کنید.","html","true",$button_back);
    }
    //===============
  elseif($command == 'set starttxt' and $from_id == $admin){
    file_put_contents("starttxt.txt","$text");
  file_put_contents("command.txt","none");
  SendMessage($chat_id,"متن استارت تنظیم شد","html","true",$button_manage);
    }
    //===============
  elseif($text == 'تنظیم پشتیبانی'and $from_id == $admin){
  file_put_contents("command.txt","set support");
  SendMessage($chat_id,"لطفا آیدی پشتیبانی را بدون @ وارد کنید","html","true",$button_back);
    }
    //===============
  elseif($command == 'set support' and $from_id == $admin){
    file_put_contents("support.txt","$text");


file_put_contents("command.txt","none");
  SendMessage($chat_id,"ایدی پشتیبانی تنظیم شد
ایدی جدید : @$text","html","true",$button_manage);
    }
  //===============
  // End Source
  if(!file_exists('user/'.$from_id)){
  mkdir('user/'.$from_id);
  }
  if(!file_exists('user/'.$from_id."/coin.txt")){
  file_put_contents('user/'.$from_id."/coin.txt","1");
  }
  $txxt = file_get_contents('Member.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('Member.txt');
      $aaddd .= $chat_id."\n";
    file_put_contents('Member.txt',$aaddd);
    }unlink('error_log');
    // توجه سورس به دلیل جلو گیری از کلاه برداری برخی افراد اپن شده است باتشکر
//=============@CreateFastBot=============//
  ?>