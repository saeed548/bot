<?php
//انتخاب اتفاقی یک شماره از 1 تا 6
$number = rand(1,41);
//با توجه به شماره انتخاب شده، یک مورد نمایش داده می شود
switch ($number){
case 1:
echo "https://i0.wp.com/wisgoon.com/media/pin/images/o/2013/7/1374942606522336.jpg";
break;
case 2:
echo "http://www.8pic.ir/images/82767741510061869501.jpeg";
break;
case 3:
echo "https://i2.wp.com/rozup.ir/up/taksara/Fun/Beautiful_Man_2.jpg";
break;
case 4:
echo "https://i1.wp.com/www.beytoote.com/images/stories/attire/hh17.jpg";
break;
case 5:
echo "http://uc.niksalehi.com/images/5p7ntdvd6xatqevacr88.jpg";
break;
case 6:
echo "https://i2.wp.com/www.irannaz.com/user_files/image/image42/0.185106001327533340_irannaz_com.jpg";
break;
case 7:
echo "http://files.facenama.com/i/attachments/1/1353863577265212_thumb.jpg";
break;
case 8:
echo "http://www.pardad.ir/uploadFiles/1Strange_men.jpg";
break;
case 9:
echo "http://www.faranaz.com/wp-content/uploads/2015/05/Funny-Pictures-Shvhrhay-worlds-ugliest-girls9.jpg";
break;
case 10:
echo "http://dl.topnaz.com/2014/04/freak-of-the-day-4.jpg";
break;
case 11:
echo "http://s10.faza98.com/dl/Ja67Xp/165.jpg";
break;
case 12:
echo "http://dl.clip2ni.com/pics2012/bestial/1360005588-j6f89i26bpfwc1gex5mt.png";
break;
case 13:
echo "http://dl.4downloads.ir/user/user1/download/fun/ax/2627_c_44.jpg";
break;
case 14:
echo "http://www.pic.tooptarinha.com/images/ay40m93073lhjtrf828o.jpg";
break;
case 15:
echo "http://www.faranaz.com/wp-content/uploads/2015/05/Funny-Pictures-Shvhrhay-worlds-ugliest-girls15.jpg";
break;
case 16:
echo "http://www.pcparsi.com/uploaded/pc6e73dbb6504867f8f2f2a1db439c1128_ugly-men-15.jpg";
break;
case 17:
echo "http://broozweb.com/wp-content/uploads/2014/02/photo-of-an-iranian-cute-boys-4.jpg";
break;
case 18:
echo "http://www.sefidak.com/images/6_pic767_www-jahaniha-com_2.jpg";
break;
case 19:
echo "http://cdn.bartarinha.ir/files/fa/news/1393/11/1/445200_645.jpg";
break;
case 20:
echo "http://cdn.tabnak.ir/files/fa/news/1389/1/19/53488_706.jpg";
break;
case 21:
echo "http://www.parsnaz.com/upload/84/0.531782001397078283_parsnaz_ir.jpg";
break;
case 22:
echo "http://www.pnuforums.ir/upload/92/6/1378927616.jpg";
break;
case 23:
echo "http://s5.picofile.com/file/8105602934/boy89686.jpg";
break;
case 24:
echo "http://www.wisgoon.com/media/pin/images/o/2015/2/11/5/236x236_1423618680613271.jpg";
break;
case 25:
echo "http://www.jahaniha.ir/wp-content/uploads/2015/08/beautiful_boy_iran_15.jpg";
break;
case 26:
echo "https://i2.wp.com/royayebarani.ir/wp-content/uploads/2014/07/8cbkuseciz5l8bfqnp2a.jpg";
break;
case 27:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/ERMIA-Amazing-ir-1.jpg";
break;
case 28:
echo "http://www.iran16.com/wp-content/uploads/13685685751.jpg";
break;
case 29:
echo "http://www.beronza.com/images/Article/aroosak-930529%20(5).jpg";
break;
case 30:
echo "http://toptoop.ir/files/pic/04105102/8252.jpg";
break;
case 31:
echo "http://broozweb.com/wp-content/uploads/2014/08/Photo-of-pretty-girls-outdoor-2.jpg";
break;
case 32:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-6.jpg";
break;
case 33:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-1.jpg";
break;
case 34:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-2.jpg";
break;
case 35:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-3.jpg";
break;
case 36:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-4.jpg";
break;
case 37:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-5.jpg";
break;
case 38:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-7.jpg";
break;
case 39:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-8.jpg";
break;
case 40:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-9.jpg";
break;
case 41:
echo "http://www.amazing.ir/wp-content/uploads/2014/06/Boy-beautifull-iranian-Amazing-ir-10.jpg";
}
?>