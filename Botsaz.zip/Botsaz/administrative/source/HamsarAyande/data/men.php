<?php
//انتخاب اتفاقی یک شماره از 1 تا 6
$number = rand(1,41);
//با توجه به شماره انتخاب شده، یک مورد نمایش داده می شود
switch ($number){
case 1:
echo "https://hammihan.com/users/users2015/status/thumbs/thumb_HamMihan-20151695379064379481447965646.0734.jpg";
break;
case 2:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/18.jpg";
break;
case 3:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/17.jpg";
break;
case 4:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/16.jpg";
break;
case 5:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/15.jpg";
break;
case 6:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/14.jpg";
break;
case 7:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/13.jpg";
break;
case 8:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/12.jpg";
break;
case 9:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/11.jpg";
break;
case 10:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/10.jpg";
break;
case 11:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/11.jpg";
break;
case 12:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/10.jpg";
break;
case 13:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/09.jpg";
break;
case 14:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/08.jpg";
break;
case 15:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/07.jpg";
break;
case 16:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/06.jpg";
break;
case 17:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/05.jpg";
break;
case 18:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/04.jpg";
break;
case 19:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/03.jpg";
break;
case 20:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/02.jpg";
break;
case 21:
echo "http://rozanehonline.com/fa/rozanehgroup/dey90/zesht-ha/01.jpg";
break;
case 22:
echo "http://imgdl1.topnop.ir/uploads/201209/tpn5753/large/dotijpkjda.jpg";
break;
case 23:
echo "http://www.nazweb.ir/upload/2015/01/The-most-ridiculous-and-ugly-makeup-hair-and-makeup-for-girls-and-women2.jpg";
break;
case 24:
echo "http://www.nazweb.ir/upload/image1/0.511703001353217531_nazweb_ir.jpg";
break;
case 25:
echo "http://rozanehonline.com/fa/rozanehgroup/aban91/ugliest-girl/26.jpg";
break;
case 26:
echo "http://palama.ir/wp-content/uploads/2016/02/%D8%B9%DA%A9%D8%B3-%D8%B5%D9%88%D8%B1%D8%AA-%D8%AF%D8%AE%D8%AA%D8%B1-%D8%AE%D9%88%D8%B4%DA%AF%D9%84-%D9%88-%D8%B2%DB%8C%D8%A8%D8%A7%DB%8C-%D8%AE%D8%A7%D8%B1%D8%AC%DB%8C-10.jpg";
break;
case 27:
echo "http://tehranmall-co.ir/wp-content/uploads/2014/08/3951-1396987540-mahta.jpg";
break;
case 28:
echo "http://www.miyanali.com/usr/Bagheri/gal4.jpg";
break;
case 29:
echo "http://www.miyanali.com/usr/Bagheri/gal6.jpg";
break;
case 30:
echo "http://toptoop.ir/files/pic/0300000/10928.jpg";
break;
case 31:
echo "https://i2.wp.com/3pide.ir/wp-content/uploads/2015/03/erfani-3pide-8.jpg";
break;
case 32:
echo "https://iranwire.com/media/uploads/Amir/2015/05/04/12.jpg";
break;
case 33:
echo "http://melliun.org/v/wp-content/uploads/2014/05/azadi-yavashaki-6.jpg";
break;
case 34:
echo "http://www.3enterfa.com/wp-content/uploads/2014/02/29153_650.jpg";
break;
case 35:
echo "http://berooztarinha.com/wp-content/uploads/2013/07/barbi-21.jpg";
break;
case 36:
echo "http://palama.ir/wp-content/uploads/2016/02/%D8%B9%DA%A9%D8%B3-%D8%B5%D9%88%D8%B1%D8%AA-%D8%AF%D8%AE%D8%AA%D8%B1-%D8%AE%D9%88%D8%B4%DA%AF%D9%84-%D9%88-%D8%B2%DB%8C%D8%A8%D8%A7%DB%8C-%D8%AE%D8%A7%D8%B1%D8%AC%DB%8C-3.jpg";
break;
case 37:
echo "http://www.parsnaz.com/images/2016/01/274806782-parsnaz-ir.jpg";
break;
case 38:
echo "http://dl.arameshpoem.com/wp-contetn/uploads/20160109/angelina.jpg";
break;
case 39:
echo "http://wikifars.com/img/general/mila-kunis-2.jpg";
break;
case 40:
echo "http://www.yourcloob.com/file/pic/photo/2014/03/99167277b29fc12c5fe11d56969a98a9_1024.jpg";
break;
case 41:
echo "https://i1.wp.com/rozup.ir/up/images4u/Pictures/2627812.png";
}
?>